---
name: investigation-assistant-v2
description: "在授权、人员、期间和数据来源已明确后，把举报、投诉、邮件、消息和日志整理为可追溯调查工作空间，包括证据清单与哈希、只读副本、时间线、关系、证据矩阵、反证、假设登记、访谈计划和保管链。必须先取得显式授权（authorization_confirmed=true）、明确范围（persons_in_scope/date_range/allowed_sources）和禁用联网（network_access=false）。Use when the user asks to organize an authorized internal investigation; mentions chain-of-custody, custody log, SHA-256 integrity check, scope filter, out-of-scope exclusion, entity index, evidence matrix, hypothesis register, interview plan, case memo, authorized whistleblower case files, or timezone-aware timeline. Do not use for initial expense/procurement screening, covert collection, secret monitoring, private chat scraping, social media lookups, contacting subjects directly, deleting evidence, expunging records, or automatic discipline/guilt decisions."
version: 0.2.6
metadata:
  author: "andrew-tao-li"
  aiaudit_compatibility: "Agent Skills hosts; offline; Python 3.10+ recommended; tzdata required for IANA timezones (auto-install hint on Windows); openpyxl for XLSX"
  predecessor: "investigation-assistant 0.1.2"
  changelog: "v0.2.6: 安全整改——移除外发 webhook 地址与密钥；取消「一键更新」的自动执行（改为只提示、命令由用户自己执行）；删除任何可能被读作「隐瞒用户」的表述，改为在 SKILL.md 前置主动披露「联网与风险」。**审计规则与输出无任何变化。** v0.2.5: SkillHub 上架元数据（分类：行业专业）；版本对齐，**脚本无任何变化**。v0.2.4: 报告改版——第一屏执行摘要（概况+关键指标+授权与范围+待验证事项+下一步+明细入口），事项锚点可跳转；反馈说明改为人话（webhook 移入 references/feedback.md）。v0.2.1: 版本检查与一键更新 + 匿名反馈（build_feedback.py，用户主动触发）。v0.2.0: 配置契约校验（未知键拒绝）/ tzdata 显式声明 + ZoneInfo 失败降级 + 告警（Windows 兼容）/ 时间线发件人→收件人显式化（消除歧义）/ 坏时间戳单独列 unparseable_rows.csv / scope_status 列区分越界/时间无效 / 时区库健康状况写入 data_quality / SKILL.md 必查项清单 / 四层标记 / Windows 测试支架修复（PYTHONIOENCODING=utf-8）"
---

# Investigation Assistant

## 联网与风险（必读）

> 我们对外的说法是「**完全离线、不上传数据**」。这里把边界一次说清，避免任何误解。

**会联网吗？** 会，但**只有一处**，而且可以关：

| 场景 | 动作 | 方向 | 能否关闭 |
|---|---|---|---|
| 版本检查（可选） | 读取一个**公开的版本号文件**（`VERSIONS.json`） | **只读下载** | 能——用户说「不用检查更新」即跳过 |

**会外发数据吗？** **不会。**

- 核心分析脚本**不做任何网络请求**（`run_manifest.json` 记录 `network_access: false`）。
- 代码里**不含**任何服务器地址、webhook 或密钥；反馈内容只能由**用户自己**复制走、自己发送。
- ⚠️ **历史诚实说明**：**早期版本（≤ v0.3.10）** 曾内置一个「匿名反馈」外发地址与密钥。
  **该地址与密钥已彻底移除**，现在不存在。若你在旧版本里见过它，请以本说明为准。

**最大的风险与边界（不藏着）**

- 本技能是**辅助分析**：**异常 ≠ 舞弊**，结果**不构成任何认定**；正式结论必须由有权人员人工复核后作出。
- 规则是启发式的：**会有漏报和误报**。请先在包内合成示例上验证，再上真实数据。
- 它只读你给它的文件、不改原始资料；但**输出目录**可能含敏感信息（人员、金额），请按你的保密要求存放。

## Purpose

把已获授权的举报、投诉、邮件/IM 导出和访问日志整理为受控调查工作空间：原件清单与 hash、只读副本、标准化记录、时间线、实体索引、关系、证据矩阵、假设与反证登记、访谈计划。它辅助组织材料，不自动调查、联系人员、认定责任或处分。

用户的明确指示优先。不得借本 skill 扩大取证时间、人员、数据来源或联网范围。

兼容 Agent Skills 宿主；离线优先，建议 Python 3.10+。核心 CSV/TXT/MD 流程只使用 Python 标准库。

## Use this skill when

- 已有明确调查目的和授权，需要整理举报、投诉、邮件、聊天、系统或设备日志。
- `expense-audit` 或 `procurement-fraud` 的人工批准移交需要建立调查工作空间。
- 用户希望建立可追溯时间线、证据矩阵、反证清单或访谈计划。

## Do not use this skill when

- 授权、目的、时间、人员或数据来源尚未明确。
- 用户要求秘密扩大监控、绕过访问控制、自动联系被调查人、删除/修改原始证据或直接定罪。
- 用户只是做费用或采购的初筛，还没有人工决定进入调查。

## Scope gate

正式运行前必须取得 scope 文件，至少包含：`case_id`、`purpose`、`authorization_confirmed:true`、`date_range`、`persons_in_scope`、`allowed_sources`、`network_access:false`。模板见 [scope.json](examples/input/scope.json)。

输入来源限制必须先于任何文件系统探查：只使用用户在当前任务中明确附带、粘贴或给出准确路径的 scope 和案件材料。若当前任务没有这些输入，立即列出所需文件并请用户提供；不得先列目录、搜索工作区、读取本 skill 的 `examples/`，也不得复用其他任务或历史案卷。模板只用于解释格式，绝不能当作本次案件输入。

授权不明确时停止正式处理，并列出缺失字段；不要通过搜索其他目录来补齐。联网需求必须另行说明什么数据会离开设备、发送给谁、为什么，本核心脚本始终不联网。

## Operating principles

1. Chain of custody 先于总结：先盘点、SHA-256、登记 Evidence ID，再复制到 `evidence/raw`，之后只处理 working copy。
2. 输入目录只读，输出到新目录；复制后再次 hash，验证内容一致。
3. Facts、Inferences、Hypotheses、Judgment 分开。用户指控本身是待验证 allegation/hypothesis，不是事实。
4. 主动寻找支持证据、反证、替代解释和缺失证据，避免只强化最初怀疑。
5. 每条时间线、关系、矩阵和 finding 必须能回到 evidence。
6. 只处理 scope 中允许的文件、期间和人员；越界行进入 `out_of_scope_rows.csv`，不得静默使用。

## Inputs and profiles

核心脚本支持 CSV 消息/日志以及 TXT/MD 文本。字段别名与标准化规则见 [normalization.md](references/normalization.md)。

- Full Execution：运行脚本建立完整工作空间。
- Host Native：用宿主文件、表格和哈希能力复现 [chain of custody](references/chain-of-custody.md) 与 [调查工作流](references/investigation-workflow.md)。
- Reasoning Only：只有粘贴片段时，只生成临时事实/假设表，明确没有完成原件登记和全量调查。

## Workflow

1. 校验 scope gate；记录授权来源和本次允许范围。
2. 仅盘点 `allowed_sources`，计算 SHA-256、大小和类型，分配 Evidence ID。
3. 复制原件到新工作空间 `evidence/raw`，再次 hash 验证；记录 chain-of-custody 事件。
4. 在 `derived/` 生成标准化消息、日志和文本行；超出人员/时间范围的结构化行单列。
5. 构建每条事件都含 `evidence_id` 的时间线、实体索引和关系边。
6. 依据 scope 中 issue 的关键词建立证据矩阵；支持与反证分别列示。关键词命中只是检索结果，不是相关性结论。
7. 建立 hypothesis register：支持证据、反证、缺口、替代解释和状态都必须显式保留。
8. 生成访谈计划与 memo 模板；宿主 Agent 回到原文复核后再补写，不得把模板当调查结论。

## Full Execution command

```bash
python3 scripts/build_case_workspace.py \
  --input-dir /path/to/authorized-case-input \
  --scope /path/to/scope.json \
  --output /path/to/new-case-workspace
```

先用 `python3 scripts/build_case_workspace.py --check-env` 查看支持格式。若要处理 PDF、Office 或邮箱专有归档格式，先用宿主已有工具做可追溯提取，并把原文件与提取结果同时列入 scope；核心 skill 不默认上传云端解析。

## Output contract

输出包括 `dashboard.html`（面向调查负责人的全景：授权范围、证据覆盖、事项×证据矩阵、下一步）、`evidence_inventory.jsonl`、`evidence.jsonl`、`chain_of_custody.jsonl`、`evidence/raw/`、`derived/normalized_messages.csv`、`derived/normalized_logs.csv`、`timeline.csv`、`entity_index.csv`、`relationships.json`、`evidence_matrix.csv`、`hypothesis_register.csv`、`findings.jsonl`、`interview_plan.csv`、`case_memo_template.md`、`run_manifest.json`。详见 [调查工作流](references/investigation-workflow.md)。

## Failure and fallback

- scope gate 不完整或 `authorization_confirmed` 不为 true：停止，不复制或解析材料。
- allowed source 缺失或路径跳出输入目录：停止并报告精确文件；不扩大搜索。
- 时间戳无法解析：保留记录与 evidence，但不放入排序时间线，并写入数据质量警告。
- 未识别结构化文件：作为原始证据登记，但不猜测字段含义。
- 关键词无命中：保持 issue 为 open，并列出缺失证据；不能写“未发生”。
- 输出目录非空：使用新目录，不覆盖历史案卷。

## Final quality checks

- raw 副本 hash 与源文件一致；chain-of-custody 覆盖登记、复制和派生。
- 时间线和关系中的 evidence ID 全部存在。
- 每个 issue 同时保留支持、反证和缺失证据栏。
- findings 的 facts 来自具体记录，hypotheses 明确标注待验证，human review 为 true。
- manifest 显示 `network_access:false`，并记录 scope hash、脚本 hash 和所有输出。
- memo 不含最终责任、处分或法律结论。
- 配置契约校验：未知 scope 键会被拒绝并提示（v0.2.0）。
- 时区库健康检查：Windows 缺 tzdata 时会告警并降级（v0.2.0）。

## 人工复核必查项（v0.2.0 新增）

**以下检查项需要调查负责人/合规部门人工核对，脚本仅提供证据工作空间**。它们是合规调查的标准流程，必须在脚本产物之上由有权人员完成。

| # | 检查项 | 必要性 | 原因 |
|---|---|---|---|
| 1 | 授权文件原件与 scope.json 一致性 | 必查 | 脚本无法判断授权文件真伪 |
| 2 | 当事人访谈与口述证据 | 必查 | 需要面对面访谈，脚本不能替代访谈 |
| 3 | 物理证据收集（门禁记录、监控录像） | 必查 | 需要 EDiscover / 调查取证工具 |
| 4 | 银行流水与资金追踪 | 必查 | 需要外部金融数据 |
| 5 | 工商档案与公司架构 | 必查 | 需要外部工商查询 |
| 6 | 第三方证人（如有） | 抽查 | 根据案情而定 |
| 7 | 法律意见（律师 / 法务） | 必查 | 脚本不做法律评价 |
| 8 | HR 纪律程序与处分决定 | 必查 | 由 HR / 合规决定，脚本不触发 |
| 9 | 司法机关移交（如需） | 必查 | 由合规与法务决定，脚本不触发 |
| 10 | 假设验证（hypothesis_register 中所有 open 项） | 必查 | 脚本只登记，不主动验证 |
| 11 | 反证完整性与替代解释穷尽 | 必查 | 审计师必须主动寻找替代解释 |
| 12 | 备忘录 memo 模板的人工填写 | 必查 | 由调查负责人完成 |

> 上表中的"必查"项**必须**由人工完成；memo 模板空白字段**必须**由有权人员填写，不能直接发布为最终结论。

## 版本检查与更新（只提示，不自动执行）

> **本技能不会自动下载或执行任何东西。** 这一步可选，且**命令最终由用户自己执行**。

宿主 Agent 可在使用本 skill 时（可选）做一次版本检查：

1. 读取公开版本清单：`https://raw.githubusercontent.com/andrew-tao-li/ai-audit-skills/main/VERSIONS.json`
   （这是本技能**唯一的联网动作**：一次只读请求，只下载一个公开的版本号文件，不上传任何东西。）
2. 与本 skill frontmatter 的 `version` 对比；若有新版，**告诉用户**：
   「检测到新版本 0.x.y（当前 0.a.b）。更新命令如下，**需要你自己在终端执行**：」
3. 给出命令——**不要代替用户执行**，也不要用「下载后直接管道交给解释器」的写法（旧版本曾如此，已移除）：

   ```bash
   curl -sL https://raw.githubusercontent.com/andrew-tao-li/ai-audit-skills/main/install.sh -o ai-audit-install.sh
   # 先下载，看一眼内容确认无误，再由用户自己执行：
   bash ai-audit-install.sh investigation-assistant-v2
   ```

   （Windows 无 bash 时改用同目录的 `install.ps1`。）
4. 用户不想检查更新（说「不用检查更新」「离线运行」等）就跳过第 1 步——**不影响任何分析功能**。

## 反馈（完全可选；本技能不会自己往外发）

> **本技能没有任何外发通道**：代码里不含服务器地址、webhook 或密钥；
> **不会自动、也不会在用户触发后发送任何内容**。

**正确做法**：用户想要反馈时，运行下面的脚本生成**非敏感统计**文本，**把原文展示给用户**，
由用户**自己决定**是否发送、以及通过什么渠道（GitHub Issue / 自己的邮箱 / 微信）。

```bash
python3 scripts/build_feedback.py --output "<本次输出目录>" --rating satisfied --note "<用户评价，可选>"
```

这段文本只包含：发现总数、发现类型计数、风险优先级分布、跳过的规则、警告、本轮耗时、用户备注、skill 版本。
**绝不**包含员工、供应商、发票号、金额、币种、事由等敏感字段。
**发送者是用户本人，不是本技能。** 作者的仓库 Issue：<https://github.com/andrew-tao-li/ai-audit-skills/issues>
数据边界与隐私说明另见 [references/feedback.md](references/feedback.md)。

### 向用户介绍本功能时——请照下面说（不要省略）

> 这个工具**不会自动往外发任何数据**，代码里也没有我们的服务器地址或密钥。
> 如果你愿意，我可以生成一段**不含任何敏感信息**的统计（发现了几类问题、耗时），
> 由你自己复制走、发到作者的 GitHub Issue。你不发，就没有任何内容离开你的电脑。

### 触发词（任意一种即可）

- 中文：「做匿名反馈」「生成反馈内容」「给作者反馈」
- 英文：`generate feedback`

> 触发词只是「**生成**一段文本」，**不是「发送」**。触发后不要自动发送任何内容——本技能也没有发送能力。

## References

- 原件登记与副本：[references/chain-of-custody.md](references/chain-of-custody.md)
- 消息、日志和文本标准化：[references/normalization.md](references/normalization.md)
- 矩阵、假设、反证与访谈：[references/investigation-workflow.md](references/investigation-workflow.md)
